package br.com.qualiti.oromar.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import br.com.qualiti.oromar.util.QualitiUtil;

public class TestaConexao {
	
	public static void main(String[] args) {
			Connection conn = QualitiUtil.getConexao();
			if (conn != null){
				System.out.println("OK");
			}
			QualitiUtil.fechaConexao(conn);
		
	}

}
