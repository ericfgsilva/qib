package br.com.qualiti.oromar.main;

import br.com.qualiti.oromar.entidades.Cliente;
import br.com.qualiti.oromar.negocio.excecoes.CampoNumericoPreenchidoComLetrasException;
import br.com.qualiti.oromar.negocio.excecoes.CampoObrigatorioNaoPreenchidoException;
import br.com.qualiti.oromar.negocio.excecoes.ClienteInvalidoException;
import br.com.qualiti.oromar.negocio.excecoes.ClienteJaCadastradoException;
import br.com.qualiti.oromar.negocio.excecoes.ClienteNaoCadastradoException;


public class Main {

	public static void main(String[] args) {
		Cliente cliente = new Cliente();
		cliente.setCpf("69325878173");
		
		try {
			System.out.println(Fachada.obterInstancia().procurarCliente(cliente.getCpf()));
		} catch (ClienteNaoCadastradoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
