package br.com.qualiti.oromar.entidades;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import br.com.qualiti.oromar.negocio.excecoes.SaldoInsuficienteException;

@Entity
@DiscriminatorValue(value="0")
public class Conta extends ContaAbstrata {

	public Conta(){
	}

	public Conta(String numero, double saldo){
		this.numero = numero;
		this.saldo = saldo;
	}

	public Conta(String numero, double saldo, Cliente cliente){
		this(numero, saldo);
		this.cliente = cliente;
	}

	public void debitar(double valor) 
			throws SaldoInsuficienteException {
		if (this.saldo >= valor){
			this.saldo -= valor;
		} else {
			throw new SaldoInsuficienteException("Seu saldo é insuficiente, deposite mais dinheiro $$ !");
		}
	}
}

