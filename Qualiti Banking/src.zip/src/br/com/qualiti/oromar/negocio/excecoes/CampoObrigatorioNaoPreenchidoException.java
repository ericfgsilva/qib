package br.com.qualiti.oromar.negocio.excecoes;

public class CampoObrigatorioNaoPreenchidoException extends Exception {

	public CampoObrigatorioNaoPreenchidoException(String mensagem) {
		super(mensagem);
	}
	
}
