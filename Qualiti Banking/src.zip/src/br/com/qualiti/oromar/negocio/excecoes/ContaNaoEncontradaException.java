package br.com.qualiti.oromar.negocio.excecoes;

public class ContaNaoEncontradaException extends Exception {

	public ContaNaoEncontradaException(String mensagem) {
		super(mensagem);
	}
	
}
