package br.com.qualiti.oromar.negocio.excecoes;

public class ClienteInvalidoException extends Exception {

	public ClienteInvalidoException(String mensagem) {
		super(mensagem);
	}
	
}
