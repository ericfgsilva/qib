package br.com.qualiti.oromar.negocio.excecoes;

public class CampoNumericoPreenchidoComLetrasException extends Exception {

	public CampoNumericoPreenchidoComLetrasException(String mensagem) {
		super(mensagem);
	}
	
}
