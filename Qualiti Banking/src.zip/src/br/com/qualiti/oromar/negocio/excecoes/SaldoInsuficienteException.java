package br.com.qualiti.oromar.negocio.excecoes;

public class SaldoInsuficienteException extends Exception {
	
	public SaldoInsuficienteException(String mensagem) {
		super(mensagem);
	}

}
