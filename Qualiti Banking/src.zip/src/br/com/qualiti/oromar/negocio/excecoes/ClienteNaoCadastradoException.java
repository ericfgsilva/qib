package br.com.qualiti.oromar.negocio.excecoes;

public class ClienteNaoCadastradoException extends Exception {

	public ClienteNaoCadastradoException(String mensagem) {
		super(mensagem);
	}
	
}
