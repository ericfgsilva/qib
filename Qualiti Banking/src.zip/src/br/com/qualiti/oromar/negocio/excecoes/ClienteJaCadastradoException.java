package br.com.qualiti.oromar.negocio.excecoes;

public class ClienteJaCadastradoException extends Exception {

	public ClienteJaCadastradoException(String mensagem) {
		super(mensagem);
	}
	
}
