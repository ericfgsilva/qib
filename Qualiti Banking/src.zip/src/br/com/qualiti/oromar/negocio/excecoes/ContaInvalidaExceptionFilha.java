package br.com.qualiti.oromar.negocio.excecoes;

public class ContaInvalidaExceptionFilha extends ContaInvalidaException {

	public ContaInvalidaExceptionFilha(String mensagem) {
		super(mensagem);
	}

}
