package br.com.qualiti.oromar.negocio.excecoes;

public class ContaJaCadastradaException extends Exception {

	public ContaJaCadastradaException(String mensagem) {
		super(mensagem);
	}
	
}
