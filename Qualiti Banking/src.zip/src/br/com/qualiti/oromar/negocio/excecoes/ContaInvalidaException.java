package br.com.qualiti.oromar.negocio.excecoes;

public class ContaInvalidaException extends Exception {

	public ContaInvalidaException(String mensagem) {
		super(mensagem);
	}
	
}
