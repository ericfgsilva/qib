package br.com.qualiti.oromar.interfaces;

import br.com.qualiti.oromar.entidades.Cliente;
import br.com.qualiti.oromar.negocio.excecoes.ClienteNaoCadastradoException;

public interface RepositorioCliente {
	
	void inserir(Cliente c);
	Cliente procurar(String cpf) throws ClienteNaoCadastradoException;
	void remover(String cpf) throws ClienteNaoCadastradoException;
	boolean existe(String cpf) throws ClienteNaoCadastradoException;
	void atualizar(Cliente c) throws ClienteNaoCadastradoException;

}
