package br.com.qualiti.oromar.interfaces;

import br.com.qualiti.oromar.entidades.Conta;
import br.com.qualiti.oromar.entidades.ContaAbstrata;
import br.com.qualiti.oromar.negocio.excecoes.ContaJaCadastradaException;
import br.com.qualiti.oromar.negocio.excecoes.ContaNaoEncontradaException;

public interface RepositorioConta {

	void inserir(ContaAbstrata c)  throws ContaJaCadastradaException;
	void remover(String num)throws ContaNaoEncontradaException;
	ContaAbstrata procurar(String num);
	void atualizar(ContaAbstrata c) throws ContaNaoEncontradaException;
	boolean existe(String numero);
	
	
}
